/** Date maths for DatePicker. Plain calendar days with no time zone, so a picked day never shifts. */

/** A calendar day. `m` counts from 0 (January), like `Date`. */
export interface Ymd { y: number; m: number; d: number }

const DATE = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/;
const pad = (n: number, w = 2) => String(n).padStart(w, '0');
const utc = (d: Ymd) => new Date(Date.UTC(d.y, d.m, d.d));
const fromUtc = (t: Date): Ymd => ({ y: t.getUTCFullYear(), m: t.getUTCMonth(), d: t.getUTCDate() });

export function daysInMonth(y: number, m: number): number {
  return new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
}

/** Reads the day from "YYYY-MM-DD" or "YYYY-MM-DDTHH:mm" (the values of native date inputs). Null when it isn't a real day. */
export function parseDate(value: string | null | undefined): Ymd | null {
  const match = value ? DATE.exec(value) : null;
  if (!match) return null;
  const y = Number(match[1]);
  const m = Number(match[2]) - 1;
  const d = Number(match[3]);
  if (m < 0 || m > 11 || d < 1 || d > daysInMonth(y, m)) return null;
  return { y, m, d };
}

/** Reads "HH:mm" from a "YYYY-MM-DDTHH:mm" value, or from "HH:mm" alone. Null when there's no valid time. */
export function parseTime(value: string | null | undefined): string | null {
  const match = value ? /(?:^|T)(\d{2}):(\d{2})$/.exec(value) : null;
  if (!match) return null;
  return Number(match[1]) < 24 && Number(match[2]) < 60 ? `${match[1]}:${match[2]}` : null;
}

export function formatYmd(d: Ymd): string {
  return `${pad(d.y, 4)}-${pad(d.m + 1)}-${pad(d.d)}`;
}

/** Today in the browser's time zone. */
export function today(now = new Date()): Ymd {
  return { y: now.getFullYear(), m: now.getMonth(), d: now.getDate() };
}

export function compare(a: Ymd, b: Ymd): number {
  return a.y - b.y || a.m - b.m || a.d - b.d;
}
export const same = (a: Ymd | null, b: Ymd | null) => !!a && !!b && compare(a, b) === 0;

export function addDays(d: Ymd, n: number): Ymd {
  const t = utc(d);
  t.setUTCDate(t.getUTCDate() + n);
  return fromUtc(t);
}

/** Moves by whole months, keeping the day where it exists (31 Jan + 1 month is 28 or 29 Feb). */
export function addMonths(d: Ymd, n: number): Ymd {
  const total = d.y * 12 + d.m + n;
  const y = Math.floor(total / 12);
  const m = total - y * 12;
  return { y, m, d: Math.min(d.d, daysInMonth(y, m)) };
}

/** 0 for Sunday to 6 for Saturday. */
export const weekday = (d: Ymd) => utc(d).getUTCDay();

export function startOfWeek(d: Ymd, weekStartsOn: 0 | 1): Ymd {
  return addDays(d, -((weekday(d) - weekStartsOn + 7) % 7));
}

/** Six weeks of seven days covering the month, so the grid keeps its height from month to month. */
export function monthGrid(y: number, m: number, weekStartsOn: 0 | 1): Ymd[][] {
  const first = startOfWeek({ y, m, d: 1 }, weekStartsOn);
  return Array.from({ length: 6 }, (_, w) => Array.from({ length: 7 }, (_, i) => addDays(first, w * 7 + i)));
}

/** True when the day is outside `min` or `max` ("YYYY-MM-DD", either may be missing). */
export function outOfRange(d: Ymd, min?: string, max?: string): boolean {
  const lo = parseDate(min);
  const hi = parseDate(max);
  return (!!lo && compare(d, lo) < 0) || (!!hi && compare(d, hi) > 0);
}

export function clampDay(d: Ymd, min?: string, max?: string): Ymd {
  const lo = parseDate(min);
  const hi = parseDate(max);
  if (lo && compare(d, lo) < 0) return lo;
  if (hi && compare(d, hi) > 0) return hi;
  return d;
}

/**
 * Where a calendar grid key moves the focused day (APG date picker dialog): arrows by a day or a week,
 * Home and End to the ends of the week, PageUp and PageDown by a month, with Shift by a year. Null for any other key.
 */
export function moveDay(d: Ymd, key: string, shift: boolean, weekStartsOn: 0 | 1): Ymd | null {
  switch (key) {
    case 'ArrowLeft': return addDays(d, -1);
    case 'ArrowRight': return addDays(d, 1);
    case 'ArrowUp': return addDays(d, -7);
    case 'ArrowDown': return addDays(d, 7);
    case 'Home': return startOfWeek(d, weekStartsOn);
    case 'End': return addDays(startOfWeek(d, weekStartsOn), 6);
    case 'PageUp': return addMonths(d, shift ? -12 : -1);
    case 'PageDown': return addMonths(d, shift ? 12 : 1);
    default: return null;
  }
}
