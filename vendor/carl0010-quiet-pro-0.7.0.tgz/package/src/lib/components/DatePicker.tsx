import { useEffect, useId, useMemo, useRef, useState, type FocusEvent, type KeyboardEvent, type MouseEvent, type ReactNode } from 'react';
import { clampDay, formatYmd, monthGrid, moveDay, outOfRange, parseDate, parseTime, same, today, type Ymd } from '../calendar';
import { cx, Field, fieldAria, Icon, ICONS, useTopLayerMenu } from '../internal';

/** Calendar height with its footer and gap: below this much room the calendar opens upwards. */
const CALENDAR_ROOM = 370;

export interface DatePickerProps {
  /** The day, "YYYY-MM-DD", or with `withTime` the day and time, "YYYY-MM-DDTHH:mm" (the same strings as native date inputs). `null` for none (controlled). */
  value?: string | null;
  /** Initial value (uncontrolled). */
  defaultValue?: string | null;
  /** Called with the new value, or `null` when cleared. */
  onChange?: (value: string | null) => void;
  /** Called when the calendar opens or closes; closing is a good moment to save a draft. */
  onOpenChange?: (open: boolean) => void;
  /** Adds a time field under the calendar, and the value carries the time. */
  withTime?: boolean;
  /** Time given to a newly picked day when `withTime` is on and no time is set yet. Default "09:00". */
  defaultTime?: string;
  /** Earliest day that can be picked, "YYYY-MM-DD". */
  min?: string;
  /** Latest day that can be picked, "YYYY-MM-DD". */
  max?: string;
  /** First column of the calendar: 0 for Sunday (default), 1 for Monday. */
  weekStartsOn?: 0 | 1;
  /** Locale for month, weekday and date names; the browser's when omitted. */
  locale?: string;
  /** Shows a Clear button in the calendar. Default true. */
  clearable?: boolean;
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
  /** Shown in the field when nothing is chosen. Default "Pick a date". */
  placeholder?: string;
  /** Accessible name when there's no visible `label`. */
  'aria-label'?: string;
  /** Submits the value with a form, through a hidden input. */
  name?: string;
  /** `sm` for toolbars and dense rows; `md` (default) for forms. */
  size?: 'sm' | 'md';
  /** Field id; generated when omitted. */
  id?: string;
  className?: string;
  disabled?: boolean;
}

const dayName = (d: Ymd, locale: string | undefined, opts: Intl.DateTimeFormatOptions) =>
  new Date(Date.UTC(d.y, d.m, d.d)).toLocaleDateString(locale, { timeZone: 'UTC', ...opts });
const timeName = (time: string, locale: string | undefined) => {
  const [h, m] = time.split(':').map(Number);
  return new Date(Date.UTC(2000, 0, 1, h, m)).toLocaleTimeString(locale, { timeZone: 'UTC', hour: 'numeric', minute: '2-digit' });
};

/**
 * A field that opens a calendar for picking a day, and with `withTime` a time (APG date picker dialog pattern).
 * In the calendar ← → move a day, ↑ ↓ a week, Home End to the ends of the week, PageUp PageDown a month (with Shift a year),
 * Enter or Space picks, Esc closes and returns focus to the field.
 */
export function DatePicker({ value: valueProp, defaultValue = null, onChange, onOpenChange, withTime = false, defaultTime = '09:00', min, max, weekStartsOn = 0, locale, clearable = true, label, hint, error, placeholder = 'Pick a date', 'aria-label': ariaLabel, name, size = 'md', id, className, disabled }: DatePickerProps) {
  const [inner, setInner] = useState<string | null>(defaultValue);
  const controlled = valueProp !== undefined;
  const value = controlled ? valueProp : inner;
  const day = parseDate(value);
  const time = parseTime(value);
  const [open, setOpen] = useState(false);
  const [upwards, setUpwards] = useState(false);
  const [focus, setFocus] = useState<Ymd>(() => day ?? clampDay(today(), min, max));
  const auto = useId();
  const fid = id ?? auto;
  const panelId = `${fid}-calendar`;
  const titleId = `${fid}-calendar-title`;
  const wrap = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const grid = useRef<HTMLTableElement>(null);
  const timeInput = useRef<HTMLInputElement>(null);
  /** True while the keyboard is in the grid, so focus follows the focused day. */
  const inGrid = useRef(false);

  const layer = useTopLayerMenu(open, upwards, trigger, panel, false);
  const now = today();
  const weeks = useMemo(() => monthGrid(focus.y, focus.m, weekStartsOn), [focus.y, focus.m, weekStartsOn]);
  const weekdays = (weeks[0] ?? []).map((d) => ({ short: dayName(d, locale, { weekday: 'narrow' }), long: dayName(d, locale, { weekday: 'long' }) }));

  useEffect(() => {
    if (!open || !inGrid.current) return;
    grid.current?.querySelector<HTMLButtonElement>('button[tabindex="0"]')?.focus();
  }, [open, focus]);

  function emit(next: string | null) {
    if (next === value) return;
    if (!controlled) setInner(next);
    onChange?.(next);
  }
  function show() {
    const box = trigger.current?.getBoundingClientRect();
    setUpwards(box ? window.innerHeight - box.bottom < CALENDAR_ROOM && box.top > window.innerHeight - box.bottom : false);
    setFocus(day ?? clampDay(today(), min, max));
    inGrid.current = true;
    setOpen(true);
    onOpenChange?.(true);
  }
  function hide(returnFocus: boolean) {
    if (!open) return;
    inGrid.current = false;
    setOpen(false);
    onOpenChange?.(false);
    if (returnFocus) trigger.current?.focus();
  }
  function pick(d: Ymd) {
    if (outOfRange(d, min, max)) return;
    setFocus(d);
    if (withTime) {
      emit(`${formatYmd(d)}T${time ?? defaultTime}`);
      inGrid.current = false;
      timeInput.current?.focus();
    } else {
      emit(formatYmd(d));
      hide(true);
    }
  }
  function changeMonth(by: number) {
    inGrid.current = false;
    setFocus((f) => moveDay(f, by < 0 ? 'PageUp' : 'PageDown', false, weekStartsOn)!);
  }

  function onGridKeyDown(e: KeyboardEvent<HTMLTableElement>) {
    const next = moveDay(focus, e.key, e.shiftKey, weekStartsOn);
    if (!next) return;
    e.preventDefault();
    inGrid.current = true;
    setFocus(next);
  }
  function onPanelKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key !== 'Escape') return;
    // Stops here so a dialog or drawer around the field stays open.
    e.preventDefault();
    e.stopPropagation();
    hide(true);
  }
  function onBlur(e: FocusEvent<HTMLDivElement>) {
    if (!wrap.current?.contains(e.relatedTarget as Node | null)) hide(false);
  }
  function keepFocus(e: MouseEvent<HTMLDivElement>) {
    // Clicks in the calendar leave focus where it is (Safari doesn't focus buttons on click, which would close it); the time field still takes focus.
    if (!(e.target as HTMLElement).closest('input')) e.preventDefault();
  }

  const shown = day ? `${dayName(day, locale, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}${withTime && time ? `, ${timeName(time, locale)}` : ''}` : placeholder;

  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div ref={wrap} className="qp-combobox" onBlur={onBlur}>
        <button ref={trigger} type="button" id={fid} disabled={disabled}
          aria-haspopup="dialog" aria-expanded={open} aria-controls={panelId} aria-label={ariaLabel ? `${ariaLabel}: ${shown}` : undefined} aria-labelledby={!ariaLabel && label ? `${fid}-label ${fid}-value` : undefined}
          {...fieldAria(fid, hint, error)}
          data-placeholder={day ? undefined : ''}
          className={cx('qp-input', 'qp-select-trigger', 'qp-datepicker-trigger', size === 'sm' && 'qp-select-sm', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}
          onClick={() => (open ? hide(false) : show())}
          onKeyDown={(e) => {
            if (!open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); show(); }
            else if (open && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); hide(false); }
          }}>
          <Icon d={ICONS.calendar} className="qp-datepicker-icon" />
          <span id={`${fid}-value`} className="qp-select-value">{shown}</span>
        </button>
        {name ? <input type="hidden" name={name} value={value ?? ''} /> : null}
        <div ref={panel} id={panelId} role="dialog" aria-modal="false" aria-labelledby={titleId}
          popover={layer ? 'manual' : undefined} hidden={layer ? undefined : !open}
          className={cx('qp-calendar', upwards && 'qp-calendar-up')}
          onKeyDown={onPanelKeyDown} onMouseDown={keepFocus}>
          <div className="qp-calendar-head">
            <button type="button" className="qp-calendar-nav" aria-label="Previous month" onClick={() => changeMonth(-1)}>
              <Icon d={ICONS.chevronLeft} />
            </button>
            <span id={titleId} className="qp-calendar-title" aria-live="polite">{dayName(focus, locale, { month: 'long', year: 'numeric' })}</span>
            <button type="button" className="qp-calendar-nav" aria-label="Next month" onClick={() => changeMonth(1)}>
              <Icon d={ICONS.chevronRight} />
            </button>
          </div>
          <table ref={grid} role="grid" aria-labelledby={titleId} className="qp-calendar-grid" onKeyDown={onGridKeyDown}>
            <thead>
              <tr>{weekdays.map((w) => <th key={w.long} scope="col" abbr={w.long}>{w.short}</th>)}</tr>
            </thead>
            <tbody>
              {weeks.map((week, wi) => (
                // Keyed by position, so a focused button stays in the page when the month changes.
                <tr key={wi}>
                  {week.map((d, di) => {
                    const isFocus = same(d, focus);
                    const blocked = outOfRange(d, min, max);
                    return (
                      <td key={di} aria-selected={same(d, day)}>
                        <button type="button" tabIndex={isFocus ? 0 : -1} disabled={blocked}
                          aria-label={dayName(d, locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                          aria-current={same(d, now) ? 'date' : undefined}
                          data-outside={d.m !== focus.m ? '' : undefined}
                          className="qp-calendar-day"
                          onClick={() => pick(d)}>
                          {d.d}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
          <div className="qp-calendar-foot">
            <button type="button" className="qp-btn qp-btn-ghost qp-btn-sm" disabled={outOfRange(now, min, max)}
              onClick={() => { setFocus(now); pick(now); }}>Today</button>
            {clearable && value ? (
              <button type="button" className="qp-btn qp-btn-ghost qp-btn-sm" onClick={() => { emit(null); hide(true); }}>Clear</button>
            ) : null}
            {withTime ? (
              <div className="qp-calendar-foot-end">
                <span className="qp-input qp-calendar-time">
                  <input ref={timeInput} type="time" aria-label="Time" value={time ?? ''}
                    onChange={(e) => { const t = parseTime(e.target.value); if (t) emit(`${formatYmd(day ?? focus)}T${t}`); }} />
                </span>
                <button type="button" className="qp-btn qp-btn-secondary qp-btn-sm" onClick={() => hide(true)}>Done</button>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </Field>
  );
}
