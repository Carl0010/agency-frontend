# Quiet Pro

A calm, dense, keyboard-first design system for SaaS tools that people use all day: task managers, admin consoles, ERPs and dashboards. Dark-first with a real light theme, tokens in OKLCH, one teal accent, Geist type, and WCAG AA contrast in both themes, checked on every push.

This repository is the single source of truth for Quiet Pro:

| What | Where |
| --- | --- |
| Design tokens (the source) | `tokens/tokens.json` |
| CSS variables, both themes (generated) | `src/lib/styles/tokens.css` |
| Component styles | `src/lib/styles/components.css` |
| React components (TypeScript) | `src/lib/` |
| Tailwind v4 + shadcn/ui bridge (generated) | `dist/tailwind.css` |
| W3C Design Tokens, DTCG 2025.10 (generated) | `dist/tokens.dark.json`, `dist/tokens.light.json` |
| Fonts (Geist, Geist Mono; SIL OFL) | `fonts/` |
| Brand book and component guidelines | `guidelines/` |
| Docs website (MUI-style: live demos, code, props tables) | `site/` |
| Files for the Claude design system artifact (bundle generated) | `artifact/` |

## Docs site

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # static site in dist-site/
```

The site has getting-started pages, foundations (colour with live contrast ratios, typography, spacing, radius and elevation), and a page per component with live examples, their source, guidelines and a props table generated from the TypeScript.

CI builds the site on every push and keeps it as a downloadable workflow artifact. To also deploy it to GitHub Pages from `main`: set **Settings → Pages → Source** to **GitHub Actions**, then add a repository variable `DEPLOY_PAGES` = `true` (**Settings → Secrets and variables → Actions → Variables**). Pages on a private repository needs a paid GitHub plan, and the published site is public.

## Using it in an app

```bash
npm install github:Carl0010/design-system
```

```tsx
// app/layout.tsx (Next.js; add '@carl0010/quiet-pro' to transpilePackages)
import '@carl0010/quiet-pro/tokens.css';
import '@carl0010/quiet-pro/components.css';

// anywhere
import { Button, Combobox } from '@carl0010/quiet-pro';
```

Set `data-theme="dark"` (default) or `"light"` on `<html>`. With Tailwind v4, also `@import "@carl0010/quiet-pro/tailwind.css"` for utilities like `bg-surface-2` and shadcn/ui variable names. The site's Installation page has the details.

## Components

Button · Input · Textarea · Select · Combobox · MultiCombobox · Checkbox · RadioGroup · Switch · Table · Badge · Avatar · Kbd · Card · Alert · Tabs · CommandMenu

## Changing the system

1. Edit the source: `tokens/tokens.json`, a component in `src/lib/components/`, a guideline in `guidelines/`, or a demo in `site/src/demos/<Component>/`.
2. Run `npm run check`. It regenerates `tokens.css`, the Tailwind bridge, the DTCG files, the props data and the Claude design system bundle, then runs the type check and tests. CI fails if generated files are out of date.
3. Preview with `npm run dev` and open a pull request.

Contrast is enforced in `scripts/tokens.test.mjs`: every text pairing the components use must reach 4.5:1, and control borders, icons and focus rings 3:1, in both themes. A new colour token needs a usage note and, if it is used for text or controls, a pairing in that test.
