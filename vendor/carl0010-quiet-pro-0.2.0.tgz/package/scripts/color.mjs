// OKLCH / hex parsing and WCAG 2.x contrast. No dependencies.

/** Parse "oklch(L C H)" (L 0–1 or %), "#rgb", "#rrggbb" or "#rrggbbaa" into linear sRGB [r, g, b] (0–1, clipped). */
export function toLinear(value) {
  const v = value.trim().toLowerCase();
  if (v.startsWith('#')) {
    let h = v.slice(1);
    if (h.length === 3 || h.length === 4) h = [...h].map((c) => c + c).join('');
    const ch = (i) => {
      const s = parseInt(h.slice(i, i + 2), 16) / 255;
      return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
    };
    return [ch(0), ch(2), ch(4)];
  }
  const m = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)\s+([\d.]+)\s*(?:\/\s*[\d.]+%?\s*)?\)$/.exec(v);
  if (!m) throw new Error(`Unsupported colour: ${value}`);
  const L = Number(m[1]) / (m[2] ? 100 : 1);
  const C = Number(m[3]);
  const H = (Number(m[4]) * Math.PI) / 180;
  const a = C * Math.cos(H);
  const b = C * Math.sin(H);
  const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const mm = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
  const clip = (x) => Math.min(1, Math.max(0, x));
  return [
    clip(4.0767416621 * l - 3.3077115913 * mm + 0.2309699292 * s),
    clip(-1.2684380046 * l + 2.6097574011 * mm - 0.3413193965 * s),
    clip(-0.0041960863 * l - 0.7034186147 * mm + 1.707614701 * s),
  ];
}

export function toHex(value) {
  const enc = (x) => {
    const s = x <= 0.0031308 ? 12.92 * x : 1.055 * x ** (1 / 2.4) - 0.055;
    return Math.round(Math.min(1, Math.max(0, s)) * 255).toString(16).padStart(2, '0');
  };
  return '#' + toLinear(value).map(enc).join('');
}

export function luminance(value) {
  const [r, g, b] = toLinear(value);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrast(a, b) {
  const x = luminance(a);
  const y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

/** { light: {name: value}, dark: {...} } from tokens.json, resolving per-theme fallbacks and {aliases}. */
export function colorsByTheme(tokens) {
  const themes = tokens.color.themes.map((t) => t.id);
  const first = themes[0];
  const out = Object.fromEntries(themes.map((t) => [t, {}]));
  for (const t of tokens.color.tokens) {
    for (const th of themes) {
      const v = typeof t.value === 'string' ? t.value : t.value[th] ?? t.value[first];
      out[th][t.name] = v;
    }
  }
  for (const th of themes) {
    for (const [k, v] of Object.entries(out[th])) {
      const alias = /^\{(.+)\}$/.exec(v);
      if (alias) out[th][k] = out[th][alias[1]];
    }
  }
  return out;
}
