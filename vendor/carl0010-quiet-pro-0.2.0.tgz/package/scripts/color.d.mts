export function toLinear(value: string): [number, number, number];
export function toHex(value: string): string;
export function luminance(value: string): number;
export function contrast(a: string, b: string): number;
export function colorsByTheme(tokens: unknown): Record<string, Record<string, string>>;
