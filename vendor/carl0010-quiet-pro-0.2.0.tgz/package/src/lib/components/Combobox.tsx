import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { cx, Field, fieldAria, Icon, ICONS } from '../internal';
import { canCreate, filterOptions, moveActive, type ListOption } from '../listbox';

const CREATE = '\u0000create';

interface ComboboxBaseProps {
  /** The full list. Filtering happens inside the component. */
  options: ListOption[];
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
  /** Describes the empty state, e.g. "Unassigned". */
  placeholder?: string;
  /** Shown when nothing matches. Default "No matches". */
  emptyText?: string;
  /** Offers "Create “…”" for typed text that matches no option. Create the item, then select it. */
  onCreate?: (label: string) => void;
  /** Accessible name when there's no visible `label` (e.g. a compact filter). */
  'aria-label'?: string;
  /** Submits the value with a form: one hidden input (MultiCombobox: one per value). */
  name?: string;
  /** Input id; generated when omitted. */
  id?: string;
  className?: string;
  disabled?: boolean;
}

function useListbox(options: ListOption[], onCreate?: (label: string) => void) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [typed, setTyped] = useState(false);
  const [active, setActive] = useState(-1);
  const listId = useId();
  const rowsFor = (text: string, hasTyped: boolean): ListOption[] => {
    const filtered = hasTyped ? filterOptions(options, text) : options;
    return onCreate && hasTyped && canCreate(options, text) ? [...filtered, { value: CREATE, label: text.trim() }] : filtered;
  };
  const rows = rowsFor(query, typed);
  useEffect(() => {
    if (open && active >= 0) document.getElementById(`${listId}-${active}`)?.scrollIntoView({ block: 'nearest' });
  }, [open, active, listId]);
  return {
    open, query, typed, active, setActive, listId, rows,
    openWith(i: number) { setOpen(true); setActive(i); },
    close() { setOpen(false); setTyped(false); setQuery(''); setActive(-1); },
    type(text: string) {
      setQuery(text); setTyped(true); setOpen(true);
      setActive(text.trim() ? moveActive(rowsFor(text, true), -1, 'ArrowDown') : -1);
    },
  };
}
type Listbox = ReturnType<typeof useListbox>;

function Options({ lb, isSelected, onPick, multi, emptyText, label }: {
  lb: Listbox; isSelected: (o: ListOption) => boolean; onPick: (o: ListOption) => void; multi?: boolean; emptyText?: string; label?: string;
}) {
  return (
    <ul id={lb.listId} role="listbox" aria-label={label} aria-multiselectable={multi || undefined} hidden={!lb.open} className="qp-listbox">
      {lb.rows.length === 0 ? <li role="presentation" className="qp-listbox-empty">{emptyText ?? 'No matches'}</li> : null}
      {lb.rows.map((o, i) => {
        const selected = isSelected(o);
        return (
          <li key={o.value} id={`${lb.listId}-${i}`} role="option" aria-selected={selected} aria-disabled={o.disabled || undefined}
            data-active={i === lb.active ? '' : undefined} className="qp-option"
            onMouseDown={(e) => e.preventDefault()} onMouseMove={() => { if (lb.active !== i) lb.setActive(i); }}
            onClick={() => { if (!o.disabled) onPick(o); }}>
            {o.value === CREATE ? (
              <><Icon d={ICONS.plus} className="qp-option-icon" /><span>Create “{o.label}”</span></>
            ) : (
              <>
                {multi ? <span className="qp-option-check" data-checked={selected ? '' : undefined} aria-hidden="true">{selected ? <Icon d={ICONS.check} size={12} /> : null}</span> : null}
                <span className="qp-option-text"><span>{o.label}</span>{o.description ? <span className="qp-option-desc">{o.description}</span> : null}</span>
                {!multi && selected ? <Icon d={ICONS.check} className="qp-option-tick" /> : null}
              </>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function comboboxAria(lb: Listbox) {
  return {
    role: 'combobox' as const,
    'aria-expanded': lb.open,
    'aria-controls': lb.listId,
    'aria-autocomplete': 'list' as const,
    'aria-activedescendant': lb.open && lb.active >= 0 ? `${lb.listId}-${lb.active}` : undefined,
    autoComplete: 'off',
    spellCheck: false,
  };
}

export interface ComboboxProps extends ComboboxBaseProps {
  /** Selected value (controlled). `null` for none. */
  value?: string | null;
  /** Initial value (uncontrolled). */
  defaultValue?: string | null;
  /** Called with the chosen value, or `null` when cleared. */
  onChange?: (value: string | null) => void;
  /** Icon inside the field before the text. */
  prefix?: ReactNode;
  /** Show the clear button and let Esc clear the value. Default true. */
  clearable?: boolean;
}

/**
 * Single-value autocomplete (ARIA 1.2 combobox). Type to filter; ↑ ↓ move, skipping disabled options;
 * Enter picks; Esc closes, and on a closed field clears the value.
 */
export function Combobox({ options, value: valueProp, defaultValue = null, onChange, label, hint, error, placeholder = 'Search…', emptyText, onCreate, prefix, clearable = true, name, 'aria-label': ariaLabel, id, className, disabled }: ComboboxProps) {
  const [inner, setInner] = useState<string | null>(defaultValue);
  const controlled = valueProp !== undefined;
  const value = controlled ? valueProp : inner;
  const setValue = (v: string | null) => { if (!controlled) setInner(v); onChange?.(v); };
  const lb = useListbox(options, onCreate);
  const auto = useId();
  const fid = id ?? auto;
  const selected = options.find((o) => o.value === value);
  const selectedIndex = lb.rows.findIndex((o) => o.value === value);

  function pick(o: ListOption) {
    if (o.value === CREATE) onCreate?.(o.label); else setValue(o.value);
    lb.close();
  }
  function onKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (lb.open) lb.setActive(moveActive(lb.rows, lb.active, e.key));
      else lb.openWith(selectedIndex >= 0 ? selectedIndex : moveActive(lb.rows, -1, e.key));
    } else if (e.key === 'Enter' && lb.open) {
      const o = lb.rows[lb.active];
      if (o && !o.disabled) { e.preventDefault(); pick(o); }
    } else if (e.key === 'Escape') {
      if (lb.open) { e.preventDefault(); lb.close(); } else if (clearable && value) { e.preventDefault(); setValue(null); }
    } else if (e.key === 'Tab') lb.close();
  }

  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className="qp-combobox">
        {name ? <input type="hidden" name={name} value={value ?? ''} /> : null}
        <div className={cx('qp-input', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}>
          {prefix ? <span className="qp-input-affix">{prefix}</span> : null}
          <input {...comboboxAria(lb)} {...fieldAria(fid, hint, error)} id={fid} disabled={disabled} aria-label={ariaLabel}
            placeholder={selected ? selected.label : placeholder}
            value={lb.typed ? lb.query : selected?.label ?? ''}
            onChange={(e) => {
              // Typing after the chosen label (caret at the end) searches only for the new text.
              const t = e.target.value;
              lb.type(!lb.typed && selected && t.startsWith(selected.label) ? t.slice(selected.label.length) : t);
            }}
            onFocus={(e) => e.currentTarget.select()}
            onClick={() => { if (!lb.open) lb.openWith(selectedIndex); }}
            onBlur={lb.close} onKeyDown={onKeyDown} />
          {clearable && value && !disabled ? (
            <button type="button" tabIndex={-1} aria-label="Clear" className="qp-input-btn"
              onMouseDown={(e) => e.preventDefault()} onClick={() => setValue(null)}>
              <Icon d={ICONS.close} size={14} />
            </button>
          ) : null}
          <Icon d={ICONS.chevronDown} className="qp-select-chevron" />
        </div>
        <Options lb={lb} isSelected={(o) => o.value === value} onPick={pick} emptyText={emptyText} label={ariaLabel} />
      </div>
    </Field>
  );
}

export interface MultiComboboxProps extends ComboboxBaseProps {
  /** Selected values (controlled). */
  values?: string[];
  /** Initial values (uncontrolled). */
  defaultValues?: string[];
  /** Called with the full new list of values. */
  onChange?: (values: string[]) => void;
}

/**
 * Multi-value autocomplete: chosen values sit as removable chips in the field. The list stays open while
 * choosing; Enter toggles the highlighted option; Backspace in an empty field removes the last chip.
 */
export function MultiCombobox({ options, values: valuesProp, defaultValues = [], onChange, label, hint, error, placeholder = 'Add…', emptyText, onCreate, name, 'aria-label': ariaLabel, id, className, disabled }: MultiComboboxProps) {
  const [inner, setInner] = useState<string[]>(defaultValues);
  const controlled = valuesProp !== undefined;
  const values = controlled ? valuesProp : inner;
  const setValues = (v: string[]) => { if (!controlled) setInner(v); onChange?.(v); };
  const lb = useListbox(options, onCreate);
  const auto = useId();
  const fid = id ?? auto;
  const inputRef = useRef<HTMLInputElement>(null);

  function toggle(o: ListOption) {
    if (o.value === CREATE) { onCreate?.(o.label); lb.close(); return; }
    setValues(values.includes(o.value) ? values.filter((v) => v !== o.value) : [...values, o.value]);
    if (lb.typed) lb.type('');
  }
  function onKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (lb.open) lb.setActive(moveActive(lb.rows, lb.active, e.key)); else lb.openWith(moveActive(lb.rows, -1, e.key));
    } else if (e.key === 'Enter' && lb.open) {
      const o = lb.rows[lb.active];
      if (o && !o.disabled) { e.preventDefault(); toggle(o); }
    } else if (e.key === 'Escape' && lb.open) { e.preventDefault(); lb.close(); }
    else if (e.key === 'Backspace' && !lb.query && values.length) setValues(values.slice(0, -1));
    else if (e.key === 'Tab') lb.close();
  }

  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className="qp-combobox">
        {name ? values.map((v) => <input key={v} type="hidden" name={name} value={v} />) : null}
        <div className={cx('qp-input', 'qp-input-multi', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}
          onClick={() => inputRef.current?.focus()}>
          {values.map((v) => {
            const o = options.find((x) => x.value === v) ?? { value: v, label: v };
            return (
              <span key={v} className="qp-chip">
                {o.label}
                {!disabled ? (
                  <button type="button" tabIndex={-1} aria-label={`Remove ${o.label}`} className="qp-chip-x"
                    onMouseDown={(e) => e.preventDefault()} onClick={(e) => { e.stopPropagation(); setValues(values.filter((x) => x !== v)); }}>
                    <Icon d={ICONS.close} size={12} />
                  </button>
                ) : null}
              </span>
            );
          })}
          <input ref={inputRef} {...comboboxAria(lb)} {...fieldAria(fid, hint, error)} id={fid} disabled={disabled} aria-label={ariaLabel}
            placeholder={values.length ? '' : placeholder} value={lb.query}
            onChange={(e) => lb.type(e.target.value)} onClick={() => { if (!lb.open) lb.openWith(-1); }}
            onBlur={lb.close} onKeyDown={onKeyDown} />
        </div>
        <Options lb={lb} isSelected={(o) => values.includes(o.value)} onPick={toggle} multi emptyText={emptyText} label={ariaLabel} />
      </div>
    </Field>
  );
}
