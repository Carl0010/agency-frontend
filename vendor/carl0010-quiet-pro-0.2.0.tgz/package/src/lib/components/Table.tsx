import type { ReactNode } from 'react';
import { cx } from '../internal';

export interface TableColumn<Row> {
  /** Row field shown in this column. */
  key: string;
  /** Column heading. */
  header: ReactNode;
  /** Right-align numbers. */
  align?: 'left' | 'right';
  /** Geist Mono with tabular figures in full text colour. Use for money, counts and IDs. */
  numeric?: boolean;
  /** Keep this column in text colour instead of text-muted. */
  strong?: boolean;
  width?: string | number;
  /** Custom cell. Defaults to `row[key]`. */
  render?: (row: Row) => ReactNode;
}

export interface TableProps<Row extends { id?: string | number; selected?: boolean }> {
  /** Column definitions, in order. */
  columns: Array<TableColumn<Row>>;
  /** `selected: true` tints a row accent-soft. The first column renders as the row header. */
  rows: Row[];
  /** Screen-reader caption. */
  caption?: string;
}

/** Dense, scannable rows of records: 36px rows, mono figures, hover and selection tints. */
export function Table<Row extends { id?: string | number; selected?: boolean }>({ columns, rows, caption }: TableProps<Row>) {
  return (
    <div className="qp-table-wrap">
      <table className="qp-table">
        {caption ? <caption className="qp-sr">{caption}</caption> : null}
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className={c.align === 'right' ? 'qp-right' : undefined} style={c.width ? { width: c.width } : undefined}>{c.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={r.id ?? ri} aria-selected={r.selected || undefined}>
              {columns.map((c, ci) => {
                const v = c.render ? c.render(r) : ((r as Record<string, unknown>)[c.key] as ReactNode);
                const cls = cx(c.align === 'right' && 'qp-right', c.numeric && 'qp-num', ci > 0 && !c.strong && 'qp-muted') || undefined;
                return ci === 0 ? <th key={c.key} scope="row" className={cls}>{v}</th> : <td key={c.key} className={cls}>{v}</td>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
