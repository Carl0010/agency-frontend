import { useId, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';
import { cx, Field, fieldAria } from '../internal';

export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  /** Visible label. Always provide one; a placeholder is not a label. */
  label?: ReactNode;
  /** Helper text under the field, linked with `aria-describedby`. */
  hint?: ReactNode;
  /** Error message. Replaces the hint, turns the border danger and sets `aria-invalid`. */
  error?: ReactNode;
  /** Icon or text inside the field before the value, such as a search icon or "₹". */
  prefix?: ReactNode;
  /** Icon or text inside the field after the value, such as a Kbd hint or a unit. */
  suffix?: ReactNode;
}

/** A single-line text field with a visible label, an optional hint and an error state. */
export function Input({ label, hint, error, prefix, suffix, id, className, disabled, ...rest }: InputProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className={cx('qp-input', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}>
        {prefix ? <span className="qp-input-affix">{prefix}</span> : null}
        <input {...rest} id={fid} disabled={disabled} {...fieldAria(fid, hint, error)} />
        {suffix ? <span className="qp-input-affix">{suffix}</span> : null}
      </div>
    </Field>
  );
}

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
}

/** Multi-line text input with the same label, hint and error states as Input. Starts at three rows. */
export function Textarea({ label, hint, error, id, className, rows = 3, ...rest }: TextareaProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <textarea {...rest} rows={rows} id={fid} className={cx('qp-textarea', error && 'qp-input-invalid')} {...fieldAria(fid, hint, error)} />
    </Field>
  );
}
