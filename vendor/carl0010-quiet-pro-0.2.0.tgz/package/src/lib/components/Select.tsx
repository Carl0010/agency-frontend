import { useId, type ReactNode, type SelectHTMLAttributes } from 'react';
import { cx, Field, fieldAria, Icon, ICONS } from '../internal';
import type { ListOption } from '../listbox';

export interface SelectProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'children'> {
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
  /** A short, fixed list. For long or searchable lists use Combobox. */
  options: ListOption[];
  /** Disabled first option shown when nothing is chosen. */
  placeholder?: string;
}

/** A native dropdown for a short, fixed list where typing to search wouldn't help. */
export function Select({ label, hint, error, options, placeholder, id, className, disabled, ...rest }: SelectProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className={cx('qp-input', 'qp-select', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}>
        <select {...rest} id={fid} disabled={disabled} {...fieldAria(fid, hint, error)}>
          {placeholder ? <option value="" disabled>{placeholder}</option> : null}
          {options.map((o) => <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>)}
        </select>
        <Icon d={ICONS.chevronDown} className="qp-select-chevron" />
      </div>
    </Field>
  );
}
