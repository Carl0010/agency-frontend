import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cx } from '../internal';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** `primary` is the one main action per view (accent fill). `secondary` is the default. `ghost` for toolbars and low emphasis. `danger` for destructive actions. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** `sm` 28px · `md` 32px · `lg` 40px. */
  size?: 'sm' | 'md' | 'lg';
  /** Shows a spinner, disables the button and sets `aria-busy`. */
  loading?: boolean;
  /** 16px icon before the label. */
  iconLeft?: ReactNode;
  /** 16px icon after the label. */
  iconRight?: ReactNode;
}

/** Triggers an action. Secondary is the default; primary is reserved for the one thing the view is for. */
export function Button({ variant = 'secondary', size = 'md', loading = false, iconLeft, iconRight, className, children, type = 'button', disabled, ...rest }: ButtonProps) {
  return (
    <button {...rest} type={type} disabled={disabled || loading} aria-busy={loading || undefined}
      className={cx('qp-btn', `qp-btn-${variant}`, `qp-btn-${size}`, className)}>
      {loading ? <span className="qp-spinner" aria-hidden="true" /> : iconLeft}
      {children != null ? <span>{children}</span> : null}
      {iconRight}
    </button>
  );
}
