import type { ReactNode } from 'react';
import { cx, Icon, ICONS } from '../internal';

export interface BadgeProps {
  /** `neutral` · `accent` · `success` · `warning` · `danger`. Tone always means a state, never decoration. */
  tone?: 'neutral' | 'accent' | 'success' | 'warning' | 'danger';
  /** Leading status dot, so status reads by shape as well as colour. */
  dot?: boolean;
  className?: string;
  children?: ReactNode;
}

/** A one- or two-word status label. */
export function Badge({ tone = 'neutral', dot, className, children }: BadgeProps) {
  return (
    <span className={cx('qp-badge', `qp-badge-${tone}`, className)}>
      {dot ? <span className="qp-badge-dot" aria-hidden="true" /> : null}
      {children}
    </span>
  );
}

export interface KbdProps {
  /** Keys in order, e.g. `['⌘', 'K']`. */
  keys: string[];
}

/** Shows a keyboard shortcut next to the action it triggers. */
export function Kbd({ keys }: KbdProps) {
  return <span className="qp-kbd-group">{keys.map((k, i) => <kbd key={i} className="qp-kbd">{k}</kbd>)}</span>;
}

export interface AvatarProps {
  /** Full name: used for the initials and the accessible label. */
  name: string;
  /** Photo URL. Initials show when omitted. */
  src?: string;
  /** `sm` 20px · `md` 28px · `lg` 40px. */
  size?: 'sm' | 'md' | 'lg';
}

/** A person's photo or initials. */
export function Avatar({ name, src, size = 'md' }: AvatarProps) {
  const parts = name.trim().split(/\s+/);
  const initials = ((parts[0]?.[0] ?? '') + (parts.length > 1 ? parts[parts.length - 1]?.[0] ?? '' : '')).toUpperCase();
  return (
    <span className={cx('qp-avatar', `qp-avatar-${size}`)} title={name} role="img" aria-label={name}>
      {src ? <img src={src} alt="" /> : initials}
    </span>
  );
}

export interface CardProps {
  /** Card title (heading-md). */
  title?: ReactNode;
  /** One line under the title. */
  description?: ReactNode;
  /** Up to two controls, top-right. */
  actions?: ReactNode;
  /** Right-aligned footer row on surface-1, for confirm and cancel. */
  footer?: ReactNode;
  /** Adds a hover border for clickable cards. */
  interactive?: boolean;
  className?: string;
  children?: ReactNode;
}

/** A bordered surface that groups one topic. Depth comes from the surface step, not a shadow. */
export function Card({ title, description, actions, footer, interactive, className, children }: CardProps) {
  return (
    <section className={cx('qp-card', interactive && 'qp-card-interactive', className)}>
      {title || actions ? (
        <header className="qp-card-head">
          <div>
            {title ? <h3 className="qp-card-title">{title}</h3> : null}
            {description ? <p className="qp-card-desc">{description}</p> : null}
          </div>
          {actions ? <div className="qp-card-actions">{actions}</div> : null}
        </header>
      ) : null}
      {children != null ? <div className="qp-card-body">{children}</div> : null}
      {footer ? <footer className="qp-card-foot">{footer}</footer> : null}
    </section>
  );
}

export interface AlertProps {
  /** `info` · `success` · `warning` · `danger`. */
  tone?: 'info' | 'success' | 'warning' | 'danger';
  /** What happened. */
  title?: ReactNode;
  /** At most one Button, right-aligned. */
  action?: ReactNode;
  className?: string;
  /** What to do next. */
  children?: ReactNode;
}

/** An inline message about the state of the page or a task. */
export function Alert({ tone = 'info', title, action, className, children }: AlertProps) {
  return (
    <div role={tone === 'danger' || tone === 'warning' ? 'alert' : 'status'} className={cx('qp-alert', `qp-alert-${tone}`, className)}>
      <Icon d={ICONS[tone]} className="qp-alert-icon" />
      <div className="qp-alert-body">
        {title ? <p className="qp-alert-title">{title}</p> : null}
        {children ? <div className="qp-alert-text">{children}</div> : null}
      </div>
      {action ? <div className="qp-alert-action">{action}</div> : null}
    </div>
  );
}
