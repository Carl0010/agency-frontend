import { useId, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { cx, Icon, ICONS } from '../internal';
import { filterOptions, moveActive } from '../listbox';
import { Kbd } from './Display';

export interface TabItem {
  /** Stable id passed to onChange. */
  id: string;
  label: ReactNode;
  /** Optional count pill, e.g. open items. */
  count?: number;
}

export interface TabsProps {
  /** Two to six tabs. */
  items: TabItem[];
  /** Selected tab id (controlled). */
  value?: string;
  /** Initial tab id (uncontrolled). Defaults to the first. */
  defaultValue?: string;
  /** Called with the selected tab id. */
  onChange?: (id: string) => void;
  /** Accessible name for the tablist. */
  label?: string;
  className?: string;
}

/** Switches between views of the same object. ← → move, Home and End jump; only the selected tab is in the Tab order. */
export function Tabs({ items, value, defaultValue, onChange, label, className }: TabsProps) {
  const [inner, setInner] = useState(defaultValue ?? items[0]?.id);
  const current = value ?? inner;
  const refs = useRef<Array<HTMLButtonElement | null>>([]);
  function select(i: number) {
    const it = items[i];
    if (!it) return;
    if (value === undefined) setInner(it.id);
    onChange?.(it.id);
    refs.current[i]?.focus();
  }
  function onKey(e: KeyboardEvent, i: number) {
    const n = items.length;
    const j = e.key === 'ArrowRight' ? (i + 1) % n : e.key === 'ArrowLeft' ? (i - 1 + n) % n : e.key === 'Home' ? 0 : e.key === 'End' ? n - 1 : -1;
    if (j >= 0) { e.preventDefault(); select(j); }
  }
  return (
    <div role="tablist" aria-label={label} className={cx('qp-tabs', className)}>
      {items.map((it, i) => {
        const on = it.id === current;
        return (
          <button key={it.id} ref={(el) => { refs.current[i] = el; }} role="tab" type="button" aria-selected={on}
            tabIndex={on ? 0 : -1} className="qp-tab" onClick={() => select(i)} onKeyDown={(e) => onKey(e, i)}>
            {it.label}
            {it.count != null ? <span className="qp-tab-count">{it.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}

export interface CommandItem {
  id?: string;
  label: string;
  /** Keys shown on the right, e.g. `['G', 'I']`. */
  shortcut?: string[];
}

export interface CommandMenuProps {
  /** Grouped actions. Every mouse-reachable action should be here. */
  groups: Array<{ heading: string; items: CommandItem[] }>;
  /** Called with the chosen item (Enter or click). */
  onSelect?: (item: CommandItem) => void;
  /** Search field placeholder. */
  placeholder?: string;
  /** Accessible name of the dialog. */
  label?: string;
  autoFocus?: boolean;
  className?: string;
}

/** The ⌘K palette: search every action and page from the keyboard. You provide open state, the scrim and focus return. */
export function CommandMenu({ groups, onSelect, placeholder = 'Type a command or search…', label = 'Command menu', autoFocus, className }: CommandMenuProps) {
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const listId = useId();
  const shown = groups
    .map((g) => ({ heading: g.heading, items: filterOptions(g.items.map((it) => ({ ...it, value: it.id ?? it.label, disabled: false })), q) }))
    .filter((g) => g.items.length);
  const flat = shown.flatMap((g) => g.items);
  function onKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); setActive(moveActive(flat, active, e.key)); }
    else if (e.key === 'Enter' && flat[active]) { e.preventDefault(); onSelect?.(flat[active]!); }
  }
  let idx = -1;
  return (
    <div className={cx('qp-cmd', className)} role="dialog" aria-label={label}>
      <div className="qp-cmd-search">
        <Icon d={ICONS.search} className="qp-cmd-search-icon" />
        <input role="combobox" aria-expanded aria-controls={listId} autoFocus={autoFocus}
          aria-activedescendant={flat[active] ? `${listId}-${active}` : undefined}
          placeholder={placeholder} value={q} onChange={(e) => { setQ(e.target.value); setActive(0); }} onKeyDown={onKeyDown} />
        <Kbd keys={['Esc']} />
      </div>
      <div className="qp-cmd-list" role="listbox" id={listId}>
        {shown.length === 0 ? <p className="qp-cmd-empty">No results for “{q}”</p> : null}
        {shown.map((g) => (
          <div key={g.heading} role="group" aria-label={g.heading}>
            <p className="qp-cmd-heading" aria-hidden="true">{g.heading}</p>
            {g.items.map((it) => {
              idx += 1;
              const i = idx;
              return (
                <div key={it.value} id={`${listId}-${i}`} role="option" aria-selected={i === active} className="qp-cmd-item"
                  onMouseMove={() => { if (active !== i) setActive(i); }} onClick={() => onSelect?.(it)}>
                  <span>{it.label}</span>
                  {it.shortcut ? <Kbd keys={it.shortcut} /> : null}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      <div className="qp-cmd-foot">
        <span><Kbd keys={['↑', '↓']} /> to navigate</span>
        <span><Kbd keys={['↵']} /> to select</span>
      </div>
    </div>
  );
}
