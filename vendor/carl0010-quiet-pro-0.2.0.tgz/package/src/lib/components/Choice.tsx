import { useId, useState, type InputHTMLAttributes, type ReactNode } from 'react';
import { cx } from '../internal';

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  /** Text beside the box. The whole row is clickable. */
  label: ReactNode;
  /** Second line under the label, in text-muted. */
  description?: ReactNode;
}

/** Turns one option on or off inside a form that's saved later. For instant settings use Switch. */
export function Checkbox({ label, description, id, className, ...rest }: CheckboxProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <label className={cx('qp-check', rest.disabled && 'qp-check-disabled', className)} htmlFor={fid}>
      <input {...rest} id={fid} type="checkbox" className="qp-check-box" />
      <span className="qp-check-text">
        <span className="qp-check-label">{label}</span>
        {description ? <span className="qp-check-desc">{description}</span> : null}
      </span>
    </label>
  );
}

export interface SwitchProps {
  /** On or off (controlled). */
  checked?: boolean;
  /** Initial state (uncontrolled). */
  defaultChecked?: boolean;
  /** Called with the new state. */
  onChange?: (checked: boolean) => void;
  /** Describes the "on" state, e.g. "Compact rows". */
  label?: ReactNode;
  disabled?: boolean;
  className?: string;
}

/** An on/off control that takes effect immediately. */
export function Switch({ checked, defaultChecked = false, onChange, label, disabled, className }: SwitchProps) {
  const [inner, setInner] = useState(defaultChecked);
  const on = checked ?? inner;
  return (
    <label className={cx('qp-switch-row', disabled && 'qp-check-disabled', className)}>
      <button type="button" role="switch" aria-checked={on} disabled={disabled} className="qp-switch"
        onClick={() => { if (checked === undefined) setInner(!on); onChange?.(!on); }}>
        <span className="qp-switch-thumb" />
      </button>
      {label ? <span className="qp-check-label">{label}</span> : null}
    </label>
  );
}

export interface RadioGroupProps {
  /** Group title, rendered as the fieldset legend. */
  legend?: ReactNode;
  /** Shared input name. Generated when omitted. */
  name?: string;
  /** Chosen value (controlled). */
  value?: string;
  /** Initial value (uncontrolled). */
  defaultValue?: string;
  /** Called with the chosen value. */
  onChange?: (value: string) => void;
  disabled?: boolean;
  /** Two to five options. */
  options: Array<{ value: string; label: ReactNode; description?: ReactNode; disabled?: boolean }>;
  className?: string;
}

/** One choice from two to five options people should compare at a glance. */
export function RadioGroup({ legend, name, value, defaultValue, onChange, disabled, options, className }: RadioGroupProps) {
  const auto = useId();
  const [inner, setInner] = useState(defaultValue);
  const current = value ?? inner;
  return (
    <fieldset className={cx('qp-radio-group', className)} disabled={disabled}>
      {legend ? <legend className="qp-field-label">{legend}</legend> : null}
      {options.map((o) => (
        <label key={o.value} className={cx('qp-check', o.disabled && 'qp-check-disabled')}>
          <input type="radio" className="qp-radio" name={name ?? auto} value={o.value} checked={current === o.value} disabled={o.disabled}
            onChange={() => { if (value === undefined) setInner(o.value); onChange?.(o.value); }} />
          <span className="qp-check-text">
            <span className="qp-check-label">{o.label}</span>
            {o.description ? <span className="qp-check-desc">{o.description}</span> : null}
          </span>
        </label>
      ))}
    </fieldset>
  );
}
