import type { ReactNode } from 'react';

/** Join class names, skipping falsy values. */
export function cx(...parts: unknown[]): string {
  return parts.filter((p): p is string => typeof p === 'string' && p.length > 0).join(' ');
}

export const ICONS = {
  plus: 'M12 5v14M5 12h14',
  check: 'm5 12 4 4L19 6',
  close: 'M18 6 6 18M6 6l12 12',
  chevronDown: 'm6 9 6 6 6-6',
  search: 'm21 21-4.3-4.3M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z',
  info: 'M12 16v-4m0-4h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0z',
  success: 'M22 11.1V12a10 10 0 1 1-5.9-9.1M22 4 12 14l-3-3',
  warning: 'M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
  danger: 'M12 8v4m0 4h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0z',
} as const;

/** 16px outline icon (Lucide-compatible geometry, 1.75 stroke), drawn in currentColor. */
export function Icon({ d, className, size = 16 }: { d: string; className?: string; size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth={1.75}
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d={d} />
    </svg>
  );
}

/** Label + control + hint/error, wired with htmlFor and aria-describedby by the caller. */
export function Field({ id, label, hint, error, className, children }: {
  id: string; label?: ReactNode; hint?: ReactNode; error?: ReactNode; className?: string; children: ReactNode;
}) {
  return (
    <div className={cx('qp-field', className)}>
      {label ? <label className="qp-field-label" htmlFor={id}>{label}</label> : null}
      {children}
      {error ? <p id={`${id}-hint`} className="qp-field-error">{error}</p> : hint ? <p id={`${id}-hint`} className="qp-field-hint">{hint}</p> : null}
    </div>
  );
}

/** aria props for a control inside Field. */
export function fieldAria(id: string, hint?: ReactNode, error?: ReactNode) {
  return {
    'aria-invalid': error ? (true as const) : undefined,
    'aria-describedby': error || hint ? `${id}-hint` : undefined,
  };
}
