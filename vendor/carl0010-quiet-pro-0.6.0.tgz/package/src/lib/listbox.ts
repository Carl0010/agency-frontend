/** Pure helpers for Select, Combobox and MultiCombobox: filtering, keyboard movement and typeahead. */
import type { ReactNode } from 'react';

export interface ListOption {
  value: string;
  label: string;
  /** Second line under the label; also searched. */
  description?: string;
  /** 16px icon, avatar or colour dot before the label. Select also shows it in the field. */
  icon?: ReactNode;
  disabled?: boolean;
}

/** Lower-case and strip accents so "jose" finds "José". */
export function fold(text: string): string {
  return text.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
}

/**
 * Options whose label or description contains every typed word, best first: label starts with the query,
 * then a word in the label starts with it, then anything else. Original order is kept within each rank.
 */
export function filterOptions<T extends ListOption>(options: readonly T[], query: string): T[] {
  const q = fold(query.trim());
  if (!q) return [...options];
  const words = q.split(/\s+/);
  const ranked: Array<{ option: T; rank: number; index: number }> = [];
  options.forEach((option, index) => {
    const label = fold(option.label);
    const haystack = option.description ? `${label} ${fold(option.description)}` : label;
    if (!words.every((w) => haystack.includes(w))) return;
    const rank = label.startsWith(q) ? 0 : label.split(/[\s\-_/.]+/).some((part) => part.startsWith(words[0]!)) ? 1 : 2;
    ranked.push({ option, rank, index });
  });
  return ranked.sort((a, b) => a.rank - b.rank || a.index - b.index).map((r) => r.option);
}

/**
 * Next enabled index for ArrowDown / ArrowUp / Home / End (wrapping) and PageDown / PageUp (up to ten
 * enabled options, stopping at the ends). Other keys keep `current`. -1 means none.
 */
export function moveActive(options: readonly Pick<ListOption, 'disabled'>[], current: number, key: string): number {
  const n = options.length;
  if (n === 0) return -1;
  const scan = (start: number, step: number) => {
    for (let k = 0, i = start; k < n; k++, i = (i + step + n) % n) if (!options[i]?.disabled) return i;
    return -1;
  };
  switch (key) {
    case 'ArrowDown': return scan(current < 0 ? 0 : (current + 1) % n, 1);
    case 'ArrowUp': return scan(current < 0 ? n - 1 : (current - 1 + n) % n, -1);
    case 'Home': return scan(0, 1);
    case 'End': return scan(n - 1, -1);
    case 'PageDown':
    case 'PageUp': {
      const step = key === 'PageDown' ? 1 : -1;
      let found = current;
      for (let i = current + step, moved = 0; i >= 0 && i < n && moved < 10; i += step) {
        if (!options[i]?.disabled) { found = i; moved++; }
      }
      return found >= 0 ? found : scan(step > 0 ? 0 : n - 1, step);
    }
    default: return current;
  }
}

/** Offer "Create …" only for non-empty text that isn't already an option's label. */
export function canCreate(options: readonly ListOption[], query: string): boolean {
  const q = fold(query.trim());
  return q.length > 0 && !options.some((o) => fold(o.label) === q);
}

/**
 * Typeahead: the next enabled option whose label starts with what was typed in quick succession,
 * searching from `current` and wrapping. Repeating one letter ("ttt") cycles through the options that
 * start with it; a longer prefix ("tue") stays on the current option while it still matches.
 * Returns `current` when nothing matches.
 */
export function typeahead(options: readonly Pick<ListOption, 'label' | 'disabled'>[], current: number, typed: string): number {
  const q = fold(typed);
  const n = options.length;
  if (!q || n === 0) return current;
  const repeated = [...q].every((ch) => ch === q[0]);
  const needle = repeated ? q[0]! : q;
  const start = repeated ? current + 1 : Math.max(current, 0);
  for (let k = 0; k < n; k++) {
    const i = (((start + k) % n) + n) % n;
    const o = options[i]!;
    if (!o.disabled && fold(o.label).startsWith(needle)) return i;
  }
  return current;
}
