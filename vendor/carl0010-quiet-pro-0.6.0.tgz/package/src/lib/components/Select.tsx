import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode, type SelectHTMLAttributes } from 'react';
import { cx, Field, fieldAria, Icon, ICONS, useTopLayerMenu } from '../internal';
import { moveActive, typeahead, type ListOption } from '../listbox';

/** How long typed letters keep adding to one typeahead search. */
const TYPEAHEAD_MS = 500;
/** Matches `.qp-listbox` max-height plus its gap: below this much room the menu opens upwards. */
const MENU_ROOM = 252;

export interface SelectProps {
  /** A fixed list, up to a few dozen. For long or growing lists use Combobox. */
  options: ListOption[];
  /** Selected value (controlled). `null` for none. */
  value?: string | null;
  /** Initial value (uncontrolled). */
  defaultValue?: string | null;
  /** Called with the chosen value. */
  onChange?: (value: string) => void;
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
  /** Shown in the field when nothing is chosen. Default "Select…". */
  placeholder?: string;
  /** Accessible name when there's no visible `label` (e.g. a compact toolbar filter). */
  'aria-label'?: string;
  /** Submits the value with a form, through a hidden native select that also joins form validation. */
  name?: string;
  /** The form can't submit until something is chosen; the browser's message points at the field. */
  required?: boolean;
  /** `sm` for toolbars and dense filters; `md` (default) for forms. */
  size?: 'sm' | 'md';
  /** Field id; generated when omitted. */
  id?: string;
  className?: string;
  disabled?: boolean;
}

/**
 * A dropdown menu for a short, fixed list (ARIA 1.2 select-only combobox). ↑ ↓ Home End PageUp PageDown move,
 * typing jumps to a matching option, Enter or Space picks, Esc closes; the menu opens upwards when there's no room below.
 */
export function Select({ options, value: valueProp, defaultValue = null, onChange, label, hint, error, placeholder = 'Select…', 'aria-label': ariaLabel, name, required, size = 'md', id, className, disabled }: SelectProps) {
  const [inner, setInner] = useState<string | null>(defaultValue);
  const controlled = valueProp !== undefined;
  const value = controlled ? valueProp : inner;
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [upwards, setUpwards] = useState(false);
  const auto = useId();
  const fid = id ?? auto;
  const listId = `${fid}-listbox`;
  const trigger = useRef<HTMLButtonElement>(null);
  const menu = useRef<HTMLUListElement>(null);
  const mirror = useRef<HTMLSelectElement>(null);
  const current = useRef(value);
  current.current = value;
  const typed = useRef({ text: '', at: 0 });

  const layer = useTopLayerMenu(open, upwards, trigger, menu);
  const selectedIndex = options.findIndex((o) => o.value === value);
  const selected = options[selectedIndex];

  // A form reset puts an uncontrolled Select back to its default, and the mirror back in step with the field.
  useEffect(() => {
    const form = mirror.current?.form;
    if (!form) return;
    const onReset = () => {
      if (!controlled) setInner(defaultValue);
      setTimeout(() => { if (mirror.current) mirror.current.value = current.current ?? ''; });
    };
    form.addEventListener('reset', onReset);
    return () => form.removeEventListener('reset', onReset);
  }, [controlled, defaultValue]);

  useEffect(() => {
    if (open && active >= 0) document.getElementById(`${listId}-${active}`)?.scrollIntoView({ block: 'nearest' });
  }, [open, active, listId]);

  function openAt(index: number) {
    const box = trigger.current?.getBoundingClientRect();
    setUpwards(box ? window.innerHeight - box.bottom < MENU_ROOM && box.top > window.innerHeight - box.bottom : false);
    setActive(index);
    setOpen(true);
  }
  function close() {
    setOpen(false);
    setActive(-1);
  }
  function choose(next: string) {
    if (next === value) return;
    if (!controlled) setInner(next);
    onChange?.(next);
  }
  function pick(index: number) {
    const o = options[index];
    if (o && !o.disabled) choose(o.value);
    close();
  }
  /** Adds a letter to the typeahead search and returns the option it lands on. */
  function typeLetter(letter: string, from: number): number {
    const now = Date.now();
    const text = now - typed.current.at < TYPEAHEAD_MS ? typed.current.text + letter : letter;
    typed.current = { text, at: now };
    return typeahead(options, from, text);
  }
  const typing = () => Date.now() - typed.current.at < TYPEAHEAD_MS && typed.current.text.length > 0;
  const firstEnabled = () => moveActive(options, -1, 'ArrowDown');

  function onKeyDown(e: KeyboardEvent<HTMLButtonElement>) {
    const { key } = e;
    const letter = key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey && !(key === ' ' && !typing());
    if (!open) {
      if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Enter' || key === ' ') {
        e.preventDefault();
        openAt(selectedIndex >= 0 ? selectedIndex : firstEnabled());
      } else if (key === 'Home' || key === 'End') {
        e.preventDefault();
        openAt(moveActive(options, -1, key));
      } else if (letter) {
        e.preventDefault();
        const i = typeLetter(key, selectedIndex);
        openAt(i >= 0 ? i : selectedIndex);
      }
      return;
    }
    if (key === 'ArrowUp' && e.altKey) {
      e.preventDefault();
      pick(active);
    } else if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Home' || key === 'End' || key === 'PageDown' || key === 'PageUp') {
      e.preventDefault();
      setActive(moveActive(options, active, key));
    } else if (key === 'Enter' || (key === ' ' && !letter)) {
      e.preventDefault();
      pick(active);
    } else if (key === 'Escape') {
      e.preventDefault();
      close();
    } else if (key === 'Tab') {
      pick(active);
    } else if (letter) {
      e.preventDefault();
      setActive(typeLetter(key, active));
    }
  }

  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className="qp-combobox">
        <button ref={trigger} type="button" id={fid} disabled={disabled}
          role="combobox" aria-haspopup="listbox" aria-expanded={open} aria-controls={listId} aria-label={ariaLabel} aria-required={required || undefined}
          aria-activedescendant={open && active >= 0 ? `${listId}-${active}` : undefined}
          {...fieldAria(fid, hint, error)}
          data-placeholder={selected ? undefined : ''}
          className={cx('qp-input', 'qp-select-trigger', size === 'sm' && 'qp-select-sm', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}
          onClick={() => (open ? close() : openAt(selectedIndex >= 0 ? selectedIndex : firstEnabled()))}
          // A button clicks on Space keyup, which would undo what keydown just did.
          onKeyDown={onKeyDown} onKeyUp={(e) => { if (e.key === ' ') e.preventDefault(); }} onBlur={close}>
          {selected?.icon ? <span className="qp-option-lead">{selected.icon}</span> : null}
          <span className="qp-select-value">{selected ? selected.label : placeholder}</span>
          <Icon d={ICONS.chevronDown} className="qp-select-chevron" />
        </button>
        {name || required ? (
          // For forms: carries `name` into FormData and `required` into validation. It sits invisibly over the
          // field (after the button, so a wrapping <label> still targets the button), and hands focus back.
          <select ref={mirror} className="qp-select-native" aria-hidden="true" tabIndex={-1} name={name} required={required} disabled={disabled}
            value={value ?? ''} onChange={(e) => choose(e.target.value)} onFocus={() => trigger.current?.focus()}>
            {options.some((o) => o.value === '') ? null : <option value="" />}
            {options.map((o) => <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>)}
          </select>
        ) : null}
        <ul ref={menu} id={listId} role="listbox" tabIndex={-1}
          popover={layer ? 'manual' : undefined} hidden={layer ? undefined : !open}
          aria-labelledby={label ? `${fid}-label` : undefined} aria-label={label ? undefined : ariaLabel}
          className={cx('qp-listbox', upwards && 'qp-listbox-up')}
          // Keep focus on the field so its keyboard handling and blur-to-close keep working.
          onMouseDown={(e) => e.preventDefault()}
          // Inside a <label>, a click would also be forwarded to the field and reopen the menu.
          onClick={(e) => e.preventDefault()}>
          {options.map((o, i) => (
            <li key={o.value} id={`${listId}-${i}`} role="option" aria-selected={o.value === value} aria-disabled={o.disabled || undefined}
              data-active={i === active ? '' : undefined} className="qp-option"
              onMouseMove={() => { if (active !== i && !o.disabled) setActive(i); }}
              onClick={() => { if (!o.disabled) pick(i); }}>
              {o.icon ? <span className="qp-option-lead">{o.icon}</span> : null}
              <span className="qp-option-text"><span>{o.label}</span>{o.description ? <span className="qp-option-desc">{o.description}</span> : null}</span>
              {o.value === value ? <Icon d={ICONS.check} className="qp-option-tick" /> : <span className="qp-option-tick" aria-hidden="true" />}
            </li>
          ))}
        </ul>
      </div>
    </Field>
  );
}

export interface NativeSelectProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'children'> {
  /** Visible label. */
  label?: ReactNode;
  /** Helper text under the field. */
  hint?: ReactNode;
  /** Error message; replaces the hint. */
  error?: ReactNode;
  /** A short, fixed list. Icons are not shown in a native menu. */
  options: ListOption[];
  /** Disabled first option shown when nothing is chosen. */
  placeholder?: string;
}

/** The platform's own dropdown, styled as a field: for mobile-first forms and plain HTML form handling. */
export function NativeSelect({ label, hint, error, options, placeholder, id, className, disabled, ...rest }: NativeSelectProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <Field id={fid} label={label} hint={hint} error={error} className={className}>
      <div className={cx('qp-input', 'qp-select', error && 'qp-input-invalid', disabled && 'qp-input-disabled')}>
        <select {...rest} id={fid} disabled={disabled} {...fieldAria(fid, hint, error)}>
          {placeholder ? <option value="" disabled>{placeholder}</option> : null}
          {options.map((o) => <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>)}
        </select>
        <Icon d={ICONS.chevronDown} className="qp-select-chevron" />
      </div>
    </Field>
  );
}
